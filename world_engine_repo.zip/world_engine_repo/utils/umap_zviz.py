# utils/umap_zviz.py
import json, os, numpy as np, matplotlib.pyplot as plt

def load_z_jsonl(path):
    return [json.loads(x) for x in open(path, "r", encoding="utf-8")]

def project(records):
    Z = np.array([r["z"] for r in records], dtype=float)
    try:
        import umap  # type: ignore
        reducer = umap.UMAP(n_neighbors=15, min_dist=0.1, metric="cosine", random_state=42)
        Z2 = reducer.fit_transform(Z); method = "UMAP"
    except Exception:
        Zc = Z - Z.mean(axis=0, keepdims=True)
        U, S, Vt = np.linalg.svd(Zc, full_matrices=False)
        Z2 = U[:, :2] * S[:2]; method = "PCA"
    return Z2, method

def plot(records, Z2, method, out_png):
    tokens = [r["token"] for r in records]
    plt.figure(figsize=(8,6))
    plt.scatter(Z2[:,0], Z2[:,1], s=16, alpha=0.8)
    for i in range(0, len(tokens), max(1, len(tokens)//30)):
        plt.text(Z2[i,0], Z2[i,1], tokens[i], fontsize=8, alpha=0.7)
    plt.title(f"WE z-space ({method})"); plt.tight_layout(); plt.savefig(out_png, dpi=180)

def main():
    in_path = os.environ.get("WE_JSONL", "data/we_v1_vectors.jsonl")
    out_png = os.environ.get("WE_Z_PNG", "data/z_space.png")
    recs = load_z_jsonl(in_path)
    Z2, method = project(recs)
    plot(recs, Z2, method, out_png)
    print(f"Saved: {out_png}")

if __name__ == "__main__":
    main()

# WE-v1 World Engine (RGCN + GATv2)

## Layout
- `models/` — RGCN (`world_engine_tg.py`) and GATv2 (`world_engine_tg_gat.py`) variants
- `utils/` — `collate_tg.py` (edge batching), `factor_naming.py`, `umap_zviz.py`
- `tests/` — PyTest checks for masking/edges/shapes
- `smoke_test_world_engine.py` — one-shot CPU sanity for both backbones
- `train_step.py` — minimal train loop utility
- `data/` — put `we_v1_vectors.jsonl`, `feature_vocab.txt`, etc.

## Install
```bash
pip install torch torch-geometric torch-scatter torch-sparse torch-cluster torch-spline-conv umap-learn matplotlib pytest pytorch-crf
```

## Quickstart
```bash
python smoke_test_world_engine.py
pytest tests/
python -m utils.umap_zviz
```

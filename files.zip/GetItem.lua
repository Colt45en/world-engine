-- Module: Rarities definition
local Rarities = {
    {"Item1", 0.00001},
    {"Item2", 0.01},
    {"Item3", 0.1}
}

return Rarities
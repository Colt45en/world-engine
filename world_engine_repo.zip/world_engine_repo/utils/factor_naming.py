# utils/factor_naming.py
import torch

def name_factors(model, feature_vocab, topk=5):
    """
    Name each latent z-dimension using top-k decoder weights (feature influence).
    model.dec_feat: Linear(z_dim -> K)
    feature_vocab: list[str] length K
    """
    W = model.dec_feat.weight.detach().T  # [K, z_dim]
    names = []
    for k in range(W.shape[1]):
        top = torch.topk(W[:,k], k=topk).indices.tolist()
        names.append([feature_vocab[i] for i in top])
    return names

# smoke_test_world_engine.py
import torch
from utils.collate_tg import build_batched_edges
from models.world_engine_tg import WorldEngineTG
from models.world_engine_tg_gat import WorldEngineTG_GAT

def main():
    B,N,K,C = 3, 7, 12, 3
    V,P,R   = 1000, 20, 8
    g = torch.Generator().manual_seed(42)
    tok = torch.randint(1,V,(B,N),generator=g)
    pos = torch.randint(1,P,(B,N),generator=g)
    feat= torch.rand(B,N,K, generator=g)
    lengths = torch.tensor([7,5,6])

    e0 = (torch.tensor([[1,4,5],[0,2,3]]), torch.tensor([0,1,2]))
    e1 = (torch.tensor([[1,3],[0,2]]),     torch.tensor([1,1]))
    e2 = (torch.tensor([[2,4,5],[1,3,0]]), torch.tensor([2,0,2]))
    edge_index, edge_type = build_batched_edges([e0,e1,e2], lengths.tolist())

    for M in (WorldEngineTG, WorldEngineTG_GAT):
        m = M(vocab_size=V, d_model=256, k_feats=K, n_pos=P, n_rels=R)
        out = m(tok, pos, feat, lengths, edge_index, edge_type)
        assert out["z"].shape == (B,32)
        assert out["feat_hat"].shape == (B,K)
        assert out["role_logits"].shape == (B,N,3)
        loss = (m.loss_reconstruction(out["feat_hat"], feat, out["mask"])
                + m.loss_roles(out["role_logits"], torch.zeros(B,N,dtype=torch.long), out["mask"]))
        loss.backward()
        for p in m.parameters():
            if p.grad is not None:
                assert torch.isfinite(p.grad).all()
        print(M.__name__, "OK", float(loss.item()))

if __name__ == "__main__":
    main()
